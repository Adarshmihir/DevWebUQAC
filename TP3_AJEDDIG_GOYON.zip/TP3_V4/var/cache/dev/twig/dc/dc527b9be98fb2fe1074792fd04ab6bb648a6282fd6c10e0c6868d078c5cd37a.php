<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/searchTrip.html.twig */
class __TwigTemplate_65c9bc778cf8513d0dfa55056e2630893e8ee39e9c19cfa9a3707ea15099a1df extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/searchTrip.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/searchTrip.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/searchTrip.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "

    <div class=\"container-fluid row\">

        <div class=\"col-md-12\"><br>
            <h1 style=\"text-align: center\">Rechercher un voyage</h1><br>
        </div>
    </div>
    ";
        // line 12
        if (((isset($context["request"]) || array_key_exists("request", $context) ? $context["request"] : (function () { throw new RuntimeError('Variable "request" does not exist.', 12, $this->source); })()) == "GET")) {
            // line 13
            echo "        <div class=\"container-fluid row\">
            <div class=\"col-md-4\"></div>
            <div class=\"col-md-4\">
                ";
            // line 16
            if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "request", []), "attributes", []), "get", [0 => "_route"], "method") == "searchTrip")) {
                // line 17
                echo "                    <a href=\"";
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("searchTripFilters");
                echo "\" style=\"text-align: center\">Plus de filtres</a>
                ";
            } else {
                // line 19
                echo "                    <a href=\"";
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("searchTrip");
                echo "\">Moins de filtres</a>
                ";
            }
            // line 21
            echo "                <br><br>
                ";
            // line 22
            $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 22, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
            // line 23
            echo "                ";
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 23, $this->source); })()), 'form');
            echo "
            </div>
        </div>
                ";
            // line 26
            if ((twig_length_filter($this->env, (isset($context["trips"]) || array_key_exists("trips", $context) ? $context["trips"] : (function () { throw new RuntimeError('Variable "trips" does not exist.', 26, $this->source); })())) != 0)) {
                // line 27
                echo "                <div class=\"form-group\">
                        <h1 class=\"text-center\">Prochains voyages</h1>
                </div>
                ";
            }
            // line 31
            echo "
            ";
        } else {
            // line 33
            echo "                <h1 class=\"text-center\">Résultats de votre recherche</h1>
                <div>
                    <a href=\"";
            // line 35
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("searchTrip");
            echo "\">Faire une autre recherche</a>
                </div>
            ";
        }
        // line 38
        echo "            <div class=\"form-group row\">
                ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["trips"]) || array_key_exists("trips", $context) ? $context["trips"] : (function () { throw new RuntimeError('Variable "trips" does not exist.', 39, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["trip"]) {
            // line 40
            echo "                        <div class=\"col-md-1\"></div>
                        <div class=\"col-md-10 border border-primary rounded\" style=\"text-align: center; padding: 3% 2% 3% 2%; margin-bottom: 5%\">
                            <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("trip", ["id" => twig_get_attribute($this->env, $this->source, $context["trip"], "id", [])]), "html", null, true);
            echo "\">Voir le détail</a><br>
                            <span class=\"font-weight-bold\">Depart :</span> ";
            // line 43
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "departureTime", []), "Y-m-d H:i"), "html", null, true);
            echo " <br>
                            <span class=\"font-weight-bold\">Adresse de départ :</span> ";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "startingPlace", []), "html", null, true);
            echo "<br>
                            <span class=\"font-weight-bold\">Adresse d'arrivée :</span> ";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "endingPlace", []), "html", null, true);
            echo "<br>
                            <span class=\"font-weight-bold\">Prix :</span> ";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "unitPricePlusFees", []), "html", null, true);
            echo " \$<br>
                            <span class=\"font-weight-bold\">";
            // line 47
            if (((twig_get_attribute($this->env, $this->source, $context["trip"], "numberPlacesRemaining", []) == 1) || (twig_get_attribute($this->env, $this->source, $context["trip"], "numberPlacesRemaining", []) == 0))) {
                echo "Nombre de place : ";
            } else {
                echo " Nombre de places : ";
            }
            echo "</span> ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "numberPlacesRemaining", []), "html", null, true);
            echo "<br>
                            <span class=\"font-weight-bold\">Type de pneu :</span> ";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "tireType", []), "html", null, true);
            echo "<br>
                            <span class=\"font-weight-bold\">Place disponible par passager :</span> ";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "availableSpacePerPassenger", []), "html", null, true);
            echo "<br>
                        </div>
                        <div class=\"col-md-1\"></div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trip'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "            </div>
            </form>
        </div>
        <div class=\"col-md-4\"></div>
    </div>
    <script>
        // Using this tutorial for autocomplete address : https://www.youtube.com/watch?v=Rpzp0yCAmq4
        function activatePlacesSearch(){
            var inputstart = document.getElementById(\"form_startPlace\");
            var inputend = document.getElementById(\"form_endPlace\");
            var autocompletestart = new google.maps.places.Autocomplete(inputstart);
            var autocompleteend = new google.maps.places.Autocomplete(inputend);
        }
    </script>
    <script type=\"text/javascript\" src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyBk5VQ6Stqy4h02d6TvvBoT3KefsYZp1lA&libraries=places&callback=activatePlacesSearch\"></script>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/searchTrip.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 53,  177 => 49,  173 => 48,  163 => 47,  159 => 46,  155 => 45,  151 => 44,  147 => 43,  143 => 42,  139 => 40,  135 => 39,  132 => 38,  126 => 35,  122 => 33,  118 => 31,  112 => 27,  110 => 26,  103 => 23,  101 => 22,  98 => 21,  92 => 19,  86 => 17,  84 => 16,  79 => 13,  77 => 12,  65 => 4,  56 => 3,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}
    {{ parent() }}

    <div class=\"container-fluid row\">

        <div class=\"col-md-12\"><br>
            <h1 style=\"text-align: center\">Rechercher un voyage</h1><br>
        </div>
    </div>
    {% if request == 'GET' %}
        <div class=\"container-fluid row\">
            <div class=\"col-md-4\"></div>
            <div class=\"col-md-4\">
                {% if app.request.attributes.get('_route') == 'searchTrip' %}
                    <a href=\"{{ url('searchTripFilters') }}\" style=\"text-align: center\">Plus de filtres</a>
                {% else %}
                    <a href=\"{{ url('searchTrip') }}\">Moins de filtres</a>
                {% endif %}
                <br><br>
                {% form_theme form 'bootstrap_4_layout.html.twig' %}
                {{ form(form) }}
            </div>
        </div>
                {% if trips|length != 0 %}
                <div class=\"form-group\">
                        <h1 class=\"text-center\">Prochains voyages</h1>
                </div>
                {% endif %}

            {% else  %}
                <h1 class=\"text-center\">Résultats de votre recherche</h1>
                <div>
                    <a href=\"{{ url('searchTrip') }}\">Faire une autre recherche</a>
                </div>
            {% endif %}
            <div class=\"form-group row\">
                {% for trip in trips %}
                        <div class=\"col-md-1\"></div>
                        <div class=\"col-md-10 border border-primary rounded\" style=\"text-align: center; padding: 3% 2% 3% 2%; margin-bottom: 5%\">
                            <a href=\"{{ url('trip', { 'id': trip.id}) }}\">Voir le détail</a><br>
                            <span class=\"font-weight-bold\">Depart :</span> {{ trip.departureTime | date('Y-m-d H:i') }} <br>
                            <span class=\"font-weight-bold\">Adresse de départ :</span> {{ trip.startingPlace }}<br>
                            <span class=\"font-weight-bold\">Adresse d'arrivée :</span> {{ trip.endingPlace }}<br>
                            <span class=\"font-weight-bold\">Prix :</span> {{ trip.unitPricePlusFees }} \$<br>
                            <span class=\"font-weight-bold\">{% if trip.numberPlacesRemaining == 1 or trip.numberPlacesRemaining == 0 %}Nombre de place : {% else %} Nombre de places : {% endif %}</span> {{ trip.numberPlacesRemaining }}<br>
                            <span class=\"font-weight-bold\">Type de pneu :</span> {{ trip.tireType }}<br>
                            <span class=\"font-weight-bold\">Place disponible par passager :</span> {{ trip.availableSpacePerPassenger }}<br>
                        </div>
                        <div class=\"col-md-1\"></div>
                {% endfor %}
            </div>
            </form>
        </div>
        <div class=\"col-md-4\"></div>
    </div>
    <script>
        // Using this tutorial for autocomplete address : https://www.youtube.com/watch?v=Rpzp0yCAmq4
        function activatePlacesSearch(){
            var inputstart = document.getElementById(\"form_startPlace\");
            var inputend = document.getElementById(\"form_endPlace\");
            var autocompletestart = new google.maps.places.Autocomplete(inputstart);
            var autocompleteend = new google.maps.places.Autocomplete(inputend);
        }
    </script>
    <script type=\"text/javascript\" src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyBk5VQ6Stqy4h02d6TvvBoT3KefsYZp1lA&libraries=places&callback=activatePlacesSearch\"></script>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
{% endblock %}", "default/searchTrip.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP3_V4/templates/default/searchTrip.html.twig");
    }
}
