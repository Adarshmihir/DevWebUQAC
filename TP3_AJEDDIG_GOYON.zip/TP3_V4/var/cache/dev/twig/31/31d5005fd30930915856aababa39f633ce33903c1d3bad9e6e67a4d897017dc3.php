<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/confirmCancelTrip.html.twig */
class __TwigTemplate_aeb700bf1856b7c567cdb5ba9d3d02a31997427f493be1e30064eff38e0ac6e2 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/confirmCancelTrip.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/confirmCancelTrip.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/confirmCancelTrip.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h1 style=\"text-align: center\">Mes voyages</h1>
            <br>
        </div>
    </div>

    ";
        // line 11
        if (((isset($context["numberPlaces"]) || array_key_exists("numberPlaces", $context) ? $context["numberPlaces"] : (function () { throw new RuntimeError('Variable "numberPlaces" does not exist.', 11, $this->source); })()) > 0)) {
            // line 12
            echo "    <div class=\"container-fluid row\" style=\"text-align: center\">
            <div class=\"col-md-4\"></div>
            <div class=\"col-md-4\">
                <a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("trip", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 15, $this->source); })()), "id", [])]), "html", null, true);
            echo "\">Ce voyage</a>, vous avez réservé ";
            echo twig_escape_filter($this->env, (isset($context["numberPlaces"]) || array_key_exists("numberPlaces", $context) ? $context["numberPlaces"] : (function () { throw new RuntimeError('Variable "numberPlaces" does not exist.', 15, $this->source); })()), "html", null, true);
            echo " places.
                <br><br>
                Confirmer l'annulation : <br><br>
                <a href=\"";
            // line 18
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("cancelTrip", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 18, $this->source); })()), "id", []), "numberPlaces" => (isset($context["numberPlaces"]) || array_key_exists("numberPlaces", $context) ? $context["numberPlaces"] : (function () { throw new RuntimeError('Variable "numberPlaces" does not exist.', 18, $this->source); })())]), "html", null, true);
            echo "\">
                    <button class=\"btn btn-danger\">
                        Cliquez ici
                    </button>
                </a>.
            </div>
            <div class=\"col-md-4\"></div>
    </div>
    ";
        } else {
            // line 27
            echo "
    <div class=\"container-fluid row\" style=\"text-align: center\">
        <div class=\"col-md-4\"></div>
        <div class=\"col-md-4\">
            De ";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 31, $this->source); })()), "startingPlace", []), "html", null, true);
            echo " à ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 31, $this->source); })()), "endingPlace", []), "html", null, true);
            echo ", le ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 31, $this->source); })()), "departureTime", []), "d/m/y"), "html", null, true);
            echo ", avec ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 31, $this->source); })()), "initialNumberPlaces", []), "html", null, true);
            echo " places.
            <br><br>
            <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("trip", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 33, $this->source); })()), "id", [])]), "html", null, true);
            echo "\">Voir le détail ici</a><br><br>
            Confirmer l'annulation <br><br>
            <a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("cancelTrip", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 35, $this->source); })()), "id", []), "numberPlaces" => 0]), "html", null, true);
            echo "\">
                <button class=\"btn btn-danger\">
                    Cliquez ici
                </button>
            </a>
        </div>
        <div class=\"col-md-2\"></div>
    </div>
    ";
        }
        // line 44
        echo "


    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/confirmCancelTrip.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 44,  126 => 35,  121 => 33,  110 => 31,  104 => 27,  92 => 18,  84 => 15,  79 => 12,  77 => 11,  65 => 3,  56 => 2,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
    {{ parent() }}
    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h1 style=\"text-align: center\">Mes voyages</h1>
            <br>
        </div>
    </div>

    {% if numberPlaces > 0 %}
    <div class=\"container-fluid row\" style=\"text-align: center\">
            <div class=\"col-md-4\"></div>
            <div class=\"col-md-4\">
                <a href=\"{{ url('trip', {id: trip.id}) }}\">Ce voyage</a>, vous avez réservé {{ numberPlaces }} places.
                <br><br>
                Confirmer l'annulation : <br><br>
                <a href=\"{{ url('cancelTrip', {id: trip.id, numberPlaces: numberPlaces}) }}\">
                    <button class=\"btn btn-danger\">
                        Cliquez ici
                    </button>
                </a>.
            </div>
            <div class=\"col-md-4\"></div>
    </div>
    {% else %}

    <div class=\"container-fluid row\" style=\"text-align: center\">
        <div class=\"col-md-4\"></div>
        <div class=\"col-md-4\">
            De {{ trip.startingPlace }} à {{ trip.endingPlace }}, le {{ trip.departureTime | date(\"d/m/y\") }}, avec {{ trip.initialNumberPlaces }} places.
            <br><br>
            <a href=\"{{ url('trip', {id: trip.id}) }}\">Voir le détail ici</a><br><br>
            Confirmer l'annulation <br><br>
            <a href=\"{{ url('cancelTrip', {id: trip.id, numberPlaces: 0}) }}\">
                <button class=\"btn btn-danger\">
                    Cliquez ici
                </button>
            </a>
        </div>
        <div class=\"col-md-2\"></div>
    </div>
    {% endif %}



    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

{% endblock %}
", "default/confirmCancelTrip.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP3_V4/templates/default/confirmCancelTrip.html.twig");
    }
}
