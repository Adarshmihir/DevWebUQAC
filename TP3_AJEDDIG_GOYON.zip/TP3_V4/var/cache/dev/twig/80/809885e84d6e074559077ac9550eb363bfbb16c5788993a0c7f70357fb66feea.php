<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/trip.html.twig */
class __TwigTemplate_f6b4feb186e8e7f308d540b4018a8a80227d4189346823f6d26278d6cba6986d extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/trip.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/trip.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/trip.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        echo "<br><br>
    ";
        // line 4
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <h1 style=\"text-align: center\">";
        // line 5
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 5, $this->source); })()), "startingPlace", []), "html", null, true);
        echo " - ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 5, $this->source); })()), "endingPlace", []), "html", null, true);
        echo " : le ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 5, $this->source); })()), "departureTime", []), "d/m/y"), "html", null, true);
        echo " à ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 5, $this->source); })()), "departureTime", []), "h:m"), "html", null, true);
        echo "</h1>
    <br><br><br>
    <div class=\"container-fluid row\" style=\"margin-bottom: 5%;\">
        <div class=\"col-md-1\"></div>
        <div class=\"col-md-4\">
            <div id=\"map\" style=\"height: 100%;\"></div>
        </div>
        <div class=\"col-md-1\"></div>
        <div class=\"col-md-4\">
            <h2>Informations générales sur le voyage et le véhicule</h2> <br>
            <b>Prix unitaire : </b> ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 15, $this->source); })()), "unitPricePlusFees", []), "html", null, true);
        echo " \$ CAD <br>
            <b>Nombre de place(s) restante(s) : </b> ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 16, $this->source); })()), "numberPlacesRemaining", []), "html", null, true);
        echo " <br>
            <b>Type de pneus : </b> ";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 17, $this->source); })()), "tireType", []), "html", null, true);
        echo " <br>
            <b>Espace disponible par passager : </b> ";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 18, $this->source); })()), "availableSpacePerPassenger", []), "html", null, true);
        echo " <br>
            <b>Air conditionné : </b> ";
        // line 19
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 19, $this->source); })()), "preference", []), "Air conditionné", [], "array")) {
            echo " Disponible ";
        } else {
            echo " Non disponible ";
        }
        // line 20
        echo "
            <br><br>

            <h2>Préférences du conducteur</h2><br>
            <b>Fumeur : </b> ";
        // line 24
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 24, $this->source); })()), "preference", []), "Fumeur autorisé dans la voiture", [], "array")) {
            echo " Autorisé dans la voiture ";
        } else {
            echo " Pas dans la voiture ";
        }
        echo " <br>
            <b>Animaux : </b> ";
        // line 25
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 25, $this->source); })()), "preference", []), "Animaux", [], "array"), "html", null, true);
        echo " <br>
            <b>Porte-vélo : </b> ";
        // line 26
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 26, $this->source); })()), "preference", []), "Porte-vélo", [], "array")) {
            echo " Présent sur le véhicule ";
        } else {
            echo " Absent ";
        }
        echo " <br>
            <b>Porte-ski : </b> ";
        // line 27
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 27, $this->source); })()), "preference", []), "Porte-ski", [], "array")) {
            echo " Présent sur le véhicule ";
        } else {
            echo " Absent ";
        }
        echo " <br>

            <br><br>
            <h2>Accès aux coordonnées du conducteur</h2><br>
            <b>Adresse mail : </b> ";
        // line 31
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 31, $this->source); })()), "preference", []), "Accès au mail après réservation", [], "array")) {
            echo " Disponible après réservation ";
        } else {
            echo " Non disponible ";
        }
        echo " <br>
            <b>Numéro de téléphone : </b> ";
        // line 32
        if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["driver"]) || array_key_exists("driver", $context) ? $context["driver"] : (function () { throw new RuntimeError('Variable "driver" does not exist.', 32, $this->source); })()), "preference", []), "Accès au numéro de téléphone après réservation", [], "array")) {
            echo " Disponible après réservation ";
        } else {
            echo " Non disponible ";
        }
        // line 33
        echo "        </div>
    </div>

    <div class=\"container-fluid row\">
        <div class=\"col-md-4\">
        </div>
        <div class=\"col-md-4\" style=\"text-align: center\">
            ";
        // line 40
        if ((twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 40, $this->source); })()), "numberPlacesRemaining", []) > 0)) {
            // line 41
            echo "                <h2>Réserver vos places</h2>
                ";
            // line 42
            $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 42, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
            // line 43
            echo "                ";
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 43, $this->source); })()), 'form');
            echo "
            ";
        }
        // line 45
        echo "        </div>
    </div>

    <script>
        var map;
        function initMap() {
            // Création de la carte.
            map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: ";
        // line 53
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 53, $this->source); })()), "latStart", []), "html", null, true);
        echo ", lng: ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 53, $this->source); })()), "lngStart", []), "html", null, true);
        echo " },
                zoom: 5
            });

            // Marqueur pour le point de départ
            var infowindow = new google.maps.InfoWindow({
                content: \"Départ\"
            });
            var marker = new google.maps.Marker({
                position: {lat: ";
        // line 62
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 62, $this->source); })()), "latStart", []), "html", null, true);
        echo ", lng: ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 62, $this->source); })()), "lngStart", []), "html", null, true);
        echo " },
                map: map,
                title: 'Point de départ'
            });
            marker.addListener('click', function() {
                infowindow.open(map, marker);
            });



            // Marqueur pour le point d'arrivée
            var infowindowEnd = new google.maps.InfoWindow({
                content: \"Arrivée\"
            });
            var markerEnd = new google.maps.Marker({
                position: {lat: ";
        // line 77
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 77, $this->source); })()), "latEnding", []), "html", null, true);
        echo ", lng: ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trip"]) || array_key_exists("trip", $context) ? $context["trip"] : (function () { throw new RuntimeError('Variable "trip" does not exist.', 77, $this->source); })()), "lngEnding", []), "html", null, true);
        echo " },
                map: map,
                title: 'Point d\\'arrivée'
            });
            markerEnd.addListener('click', function() {
                infowindowEnd.open(map, markerEnd);
            });
        }
    </script>
    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyBk5VQ6Stqy4h02d6TvvBoT3KefsYZp1lA&callback=initMap\"
            async defer></script>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/trip.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 77,  209 => 62,  195 => 53,  185 => 45,  179 => 43,  177 => 42,  174 => 41,  172 => 40,  163 => 33,  157 => 32,  149 => 31,  138 => 27,  130 => 26,  126 => 25,  118 => 24,  112 => 20,  106 => 19,  102 => 18,  98 => 17,  94 => 16,  90 => 15,  71 => 5,  67 => 4,  56 => 3,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}<br><br>
    {{ parent() }}
    <h1 style=\"text-align: center\">{{ trip.startingPlace }} - {{ trip.endingPlace }} : le {{ trip.departureTime|date('d/m/y') }} à {{ trip.departureTime|date('h:m') }}</h1>
    <br><br><br>
    <div class=\"container-fluid row\" style=\"margin-bottom: 5%;\">
        <div class=\"col-md-1\"></div>
        <div class=\"col-md-4\">
            <div id=\"map\" style=\"height: 100%;\"></div>
        </div>
        <div class=\"col-md-1\"></div>
        <div class=\"col-md-4\">
            <h2>Informations générales sur le voyage et le véhicule</h2> <br>
            <b>Prix unitaire : </b> {{ trip.unitPricePlusFees }} \$ CAD <br>
            <b>Nombre de place(s) restante(s) : </b> {{ trip.numberPlacesRemaining }} <br>
            <b>Type de pneus : </b> {{ trip.tireType }} <br>
            <b>Espace disponible par passager : </b> {{ trip.availableSpacePerPassenger }} <br>
            <b>Air conditionné : </b> {% if driver.preference[\"Air conditionné\"] %} Disponible {% else %} Non disponible {% endif %}

            <br><br>

            <h2>Préférences du conducteur</h2><br>
            <b>Fumeur : </b> {% if driver.preference[\"Fumeur autorisé dans la voiture\"] %} Autorisé dans la voiture {% else %} Pas dans la voiture {% endif %} <br>
            <b>Animaux : </b> {{ driver.preference[\"Animaux\"] }} <br>
            <b>Porte-vélo : </b> {% if driver.preference[\"Porte-vélo\"] %} Présent sur le véhicule {% else %} Absent {% endif %} <br>
            <b>Porte-ski : </b> {% if driver.preference[\"Porte-ski\"] %} Présent sur le véhicule {% else %} Absent {% endif %} <br>

            <br><br>
            <h2>Accès aux coordonnées du conducteur</h2><br>
            <b>Adresse mail : </b> {% if driver.preference[\"Accès au mail après réservation\"] %} Disponible après réservation {% else %} Non disponible {% endif %} <br>
            <b>Numéro de téléphone : </b> {% if driver.preference[\"Accès au numéro de téléphone après réservation\"] %} Disponible après réservation {% else %} Non disponible {% endif %}
        </div>
    </div>

    <div class=\"container-fluid row\">
        <div class=\"col-md-4\">
        </div>
        <div class=\"col-md-4\" style=\"text-align: center\">
            {% if trip.numberPlacesRemaining > 0 %}
                <h2>Réserver vos places</h2>
                {% form_theme form 'bootstrap_4_layout.html.twig' %}
                {{ form(form) }}
            {% endif %}
        </div>
    </div>

    <script>
        var map;
        function initMap() {
            // Création de la carte.
            map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: {{ trip.latStart }}, lng: {{ trip.lngStart}} },
                zoom: 5
            });

            // Marqueur pour le point de départ
            var infowindow = new google.maps.InfoWindow({
                content: \"Départ\"
            });
            var marker = new google.maps.Marker({
                position: {lat: {{ trip.latStart }}, lng: {{ trip.lngStart}} },
                map: map,
                title: 'Point de départ'
            });
            marker.addListener('click', function() {
                infowindow.open(map, marker);
            });



            // Marqueur pour le point d'arrivée
            var infowindowEnd = new google.maps.InfoWindow({
                content: \"Arrivée\"
            });
            var markerEnd = new google.maps.Marker({
                position: {lat: {{ trip.latEnding }}, lng: {{ trip.lngEnding }} },
                map: map,
                title: 'Point d\\'arrivée'
            });
            markerEnd.addListener('click', function() {
                infowindowEnd.open(map, markerEnd);
            });
        }
    </script>
    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyBk5VQ6Stqy4h02d6TvvBoT3KefsYZp1lA&callback=initMap\"
            async defer></script>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
{% endblock %}", "default/trip.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP3_V4/templates/default/trip.html.twig");
    }
}
