<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @FOSUser/Profile/show_content.html.twig */
class __TwigTemplate_6c63eb388cc218572c62eef9655594ae25ca43e9079e164f873b673fcd2484c6 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@FOSUser/Profile/show_content.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@FOSUser/Profile/show_content.html.twig"));

        // line 2
        echo "<br><br>
<div class=\"fos_user_user_show container bg-light border\">
    <div class=\"row text-center border-bottom\">
        <p class=\"col-4 my-auto\"><span class=\"font-weight-bold\">";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profile.show.username", [], "FOSUserBundle"), "html", null, true);
        echo "</span> : ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 5, $this->source); })()), "username", []), "html", null, true);
        echo "</p>
        <p class=\"col-4 my-auto\"><span class=\"font-weight-bold\">";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profile.show.email", [], "FOSUserBundle"), "html", null, true);
        echo "</span> : ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 6, $this->source); })()), "email", []), "html", null, true);
        echo "</p>
        <a class=\"btn btn-primary col-4\" href=\"";
        // line 7
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("editPrivateInfo");
        echo "\">Modifier mes informations personnelles</a>
    </div>
    <ul class=\"list-group\"><br>
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 10, $this->source); })()), "preference", []));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 11
            echo "            <li class=\"list-group-item\"><span class=\"font-weight-bold\">";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "</span> :
            ";
            // line 12
            if ($context["item"]) {
                // line 13
                echo "                ";
                if (($context["key"] == "Animaux")) {
                    // line 14
                    echo "                    ";
                    echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                    echo "
                ";
                } else {
                    // line 16
                    echo "                    Oui
                ";
                }
                // line 18
                echo "            ";
            } else {
                // line 19
                echo "                Non
            ";
            }
            // line 20
            echo "</li>
            <br>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "    </ul>
</div>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Profile/show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 23,  95 => 20,  91 => 19,  88 => 18,  84 => 16,  78 => 14,  75 => 13,  73 => 12,  68 => 11,  64 => 10,  58 => 7,  52 => 6,  46 => 5,  41 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{% trans_default_domain 'FOSUserBundle' %}
<br><br>
<div class=\"fos_user_user_show container bg-light border\">
    <div class=\"row text-center border-bottom\">
        <p class=\"col-4 my-auto\"><span class=\"font-weight-bold\">{{ 'profile.show.username'|trans }}</span> : {{ user.username }}</p>
        <p class=\"col-4 my-auto\"><span class=\"font-weight-bold\">{{ 'profile.show.email'|trans }}</span> : {{ user.email }}</p>
        <a class=\"btn btn-primary col-4\" href=\"{{ url('editPrivateInfo') }}\">Modifier mes informations personnelles</a>
    </div>
    <ul class=\"list-group\"><br>
        {% for key, item in user.preference %}
            <li class=\"list-group-item\"><span class=\"font-weight-bold\">{{ key }}</span> :
            {% if item %}
                {% if key == 'Animaux' %}
                    {{ item }}
                {% else %}
                    Oui
                {% endif %}
            {% else %}
                Non
            {% endif %}</li>
            <br>
        {% endfor %}
    </ul>
</div>
", "@FOSUser/Profile/show_content.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP3_V4/templates/bundles/FOSUserBundle/Profile/show_content.html.twig");
    }
}
