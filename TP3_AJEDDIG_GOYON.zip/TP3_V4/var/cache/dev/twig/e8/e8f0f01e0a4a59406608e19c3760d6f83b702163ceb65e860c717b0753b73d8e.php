<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/myTrip.html.twig */
class __TwigTemplate_05a86f87e2bce748b8c63eb476ef5e1cddcc62f129355ee8c68752f9ba387fa9 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/myTrip.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/myTrip.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "default/myTrip.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h1 style=\"text-align: center\">Mes voyages</h1>
            <br>
        </div>
    </div>

    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h2 style=\"text-align: center\">Mes réservations</h2>
            <br>
        </div>
    </div>

    ";
        // line 18
        if ((twig_length_filter($this->env, (isset($context["TripSave"]) || array_key_exists("TripSave", $context) ? $context["TripSave"] : (function () { throw new RuntimeError('Variable "TripSave" does not exist.', 18, $this->source); })())) == 0)) {
            // line 19
            echo "        <h4 style=\"text-align: center\">Vous n'avez encore aucune réservation ...</h4>
    ";
        }
        // line 21
        echo "
    <div class=\"container-fluid row\" style=\"text-align: center\">
        ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["TripSave"]) || array_key_exists("TripSave", $context) ? $context["TripSave"] : (function () { throw new RuntimeError('Variable "TripSave" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["trip"]) {
            // line 24
            echo "            <div class=\"col-md-3 border\" style=\"margin-left: 4.1%; margin-right: 4.1%; margin-bottom: 4.1%; padding: 1%;\">
                <a href=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("trip", ["id" => twig_get_attribute($this->env, $this->source, $context["trip"], "idTrip", [])]), "html", null, true);
            echo "\">Ce voyage</a>, vous avez réservé ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "numberPlaces", []), "html", null, true);
            echo " ";
            if ((twig_get_attribute($this->env, $this->source, $context["trip"], "numberPlaces", []) == 1)) {
                echo " place. ";
            } else {
                echo " places. ";
            }
            // line 26
            echo "                <br>
                ";
            // line 27
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("App\\Controller\\DefaultController::getUserAction", ["id" => twig_get_attribute($this->env, $this->source,             // line 29
$context["trip"], "idTrip", [])]));
            // line 30
            echo "<br>
                Un imprévu ? Vous devez annuler votre réservation ?
                <a href=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("confirmCancelTrip", ["id" => twig_get_attribute($this->env, $this->source, $context["trip"], "idTrip", []), "numberPlaces" => twig_get_attribute($this->env, $this->source, $context["trip"], "numberPlaces", [])]), "html", null, true);
            echo "\">Cliquez ici</a>.
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trip'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </div>

    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h2 style=\"text-align: center\">Mes propositions</h2>
            <br>
        </div>
    </div>


    ";
        // line 45
        if ((twig_length_filter($this->env, (isset($context["trips"]) || array_key_exists("trips", $context) ? $context["trips"] : (function () { throw new RuntimeError('Variable "trips" does not exist.', 45, $this->source); })())) == 0)) {
            // line 46
            echo "        <h4 style=\"text-align: center\">Vous n'avez encore proposé aucun voyage ...</h4>
    ";
        }
        // line 48
        echo "
    <div class=\"container-fluid row\">
        ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["trips"]) || array_key_exists("trips", $context) ? $context["trips"] : (function () { throw new RuntimeError('Variable "trips" does not exist.', 50, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["trip"]) {
            // line 51
            echo "            <div class=\"col-md-3 border\" style=\"margin: 0 4.1% 4.1% 4.1%; text-align: center; padding: 1%;\">
                De ";
            // line 52
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "startingPlace", []), "html", null, true);
            echo " à ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "endingPlace", []), "html", null, true);
            echo ", le ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "departureTime", []), "d/m/y"), "html", null, true);
            echo ", avec ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["trip"], "initialNumberPlaces", []), "html", null, true);
            echo " places.
                <br>
                <a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("trip", ["id" => twig_get_attribute($this->env, $this->source, $context["trip"], "id", [])]), "html", null, true);
            echo "\">Voir le détail ici</a><br>
                Vous devez annuler votre proposition ? <a href=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("confirmCancelTrip", ["id" => twig_get_attribute($this->env, $this->source, $context["trip"], "id", []), "numberPlaces" => 0]), "html", null, true);
            echo "\">cliquez ici</a>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trip'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "    </div>



    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/myTrip.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 58,  174 => 55,  170 => 54,  159 => 52,  156 => 51,  152 => 50,  148 => 48,  144 => 46,  142 => 45,  130 => 35,  121 => 32,  117 => 30,  115 => 29,  114 => 27,  111 => 26,  101 => 25,  98 => 24,  94 => 23,  90 => 21,  86 => 19,  84 => 18,  65 => 3,  56 => 2,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
    {{ parent() }}
    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h1 style=\"text-align: center\">Mes voyages</h1>
            <br>
        </div>
    </div>

    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h2 style=\"text-align: center\">Mes réservations</h2>
            <br>
        </div>
    </div>

    {% if TripSave|length == 0 %}
        <h4 style=\"text-align: center\">Vous n'avez encore aucune réservation ...</h4>
    {% endif %}

    <div class=\"container-fluid row\" style=\"text-align: center\">
        {% for trip in TripSave %}
            <div class=\"col-md-3 border\" style=\"margin-left: 4.1%; margin-right: 4.1%; margin-bottom: 4.1%; padding: 1%;\">
                <a href=\"{{ url('trip', {id: trip.idTrip}) }}\">Ce voyage</a>, vous avez réservé {{ trip.numberPlaces }} {% if trip.numberPlaces == 1 %} place. {% else %} places. {% endif %}
                <br>
                {{ render(controller(
                    'App\\\\Controller\\\\DefaultController::getUserAction',
                    { 'id': trip.idTrip}
                )) }}<br>
                Un imprévu ? Vous devez annuler votre réservation ?
                <a href=\"{{ url('confirmCancelTrip', {id: trip.idTrip, numberPlaces: trip.numberPlaces}) }}\">Cliquez ici</a>.
            </div>
        {% endfor %}
    </div>

    <div class=\"container-fluid row\">
        <div class=\"col-md-12\"><br>
            <h2 style=\"text-align: center\">Mes propositions</h2>
            <br>
        </div>
    </div>


    {% if trips|length == 0 %}
        <h4 style=\"text-align: center\">Vous n'avez encore proposé aucun voyage ...</h4>
    {% endif %}

    <div class=\"container-fluid row\">
        {% for trip in trips %}
            <div class=\"col-md-3 border\" style=\"margin: 0 4.1% 4.1% 4.1%; text-align: center; padding: 1%;\">
                De {{ trip.startingPlace }} à {{ trip.endingPlace }}, le {{ trip.departureTime | date(\"d/m/y\") }}, avec {{ trip.initialNumberPlaces }} places.
                <br>
                <a href=\"{{ url('trip', {id: trip.id}) }}\">Voir le détail ici</a><br>
                Vous devez annuler votre proposition ? <a href=\"{{ url('confirmCancelTrip', {id: trip.id, numberPlaces: 0}) }}\">cliquez ici</a>
            </div>
        {% endfor %}
    </div>



    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

{% endblock %}
", "default/myTrip.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP3_V4/templates/default/myTrip.html.twig");
    }
}
