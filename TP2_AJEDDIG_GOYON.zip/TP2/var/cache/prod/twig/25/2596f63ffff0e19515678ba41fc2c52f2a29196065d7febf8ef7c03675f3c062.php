<?php

/* default/index.html.twig */
class __TwigTemplate_6720ed28a78006d33c51297db4c1b810cb555507e700d85fdfc032d40606de23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        // line 4
        echo "    <div class=\"container-fluid center-block\" style=\"text-align: center\"><br><br>
        <h1>Comptes bancaires</h1>
        <a class=\"btn btn-light btn-outline-dark btn-sm\" href=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("createAccount");
        echo "\">Créer un compte</a><br><br>
        <div class=\"row\">
            <div class=\"col-md-3\"><br></div>
            <div class=\"col-md-6\">
                <table class=\"table table-striped\">
                    <thead>
                    <tr>
                        <th scope=\"col\">#</th>
                        <th scope=\"col\">Propriétaire</th>
                        <th scope=\"col\">Montant</th>
                        <th scope=\"col\">Dernière opération</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["accountList"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["account"]) {
            // line 21
            echo "                            <th scope=\"row\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["account"], "id", []), "html", null, true);
            echo "</th>
                            <td><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("makeChanges", ["id" => $this->getAttribute($context["account"], "id", [])]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["account"], "owner", []), "html", null, true);
            echo "</a></td>
                            <td><a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("makeChanges", ["id" => $this->getAttribute($context["account"], "id", [])]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["account"], "amount", []), "html", null, true);
            echo " \$</a></td>
                            <td><a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("makeChanges", ["id" => $this->getAttribute($context["account"], "id", [])]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["account"], "lastOp", []), "d/m/y"), "html", null, true);
            echo "</a></td>
                        </tr></a>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['account'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "                    </tbody>
                </table>
            </div>
        </div>
    </div>
";
    }

    // line 34
    public function block_stylesheets($context, array $blocks = [])
    {
        echo " ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 34,  85 => 27,  74 => 24,  68 => 23,  62 => 22,  57 => 21,  53 => 20,  36 => 6,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/index.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP2/app/Resources/views/default/index.html.twig");
    }
}
