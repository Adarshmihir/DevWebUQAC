<?php

/* default/position.html.twig */
class __TwigTemplate_0322df7be69f7f9568b353d298d203da390a277d4f9cf797fc00d9207d658119 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/position.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        // line 4
        echo "    <div class=\"container-fluid center-block\" style=\"text-align: center\"><br><br>
        <h1>Position du compte \"";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["account"] ?? null), "owner", []), "html", null, true);
        echo "\"</h1>
    </div><br><br>
    <div class=\"row container-fluid center\">
        <div class=\"col-md-3\"></div>
        <div class=\"col-md-6\" style=\"text-align: center;\">
            <i style=\"font-weight: bold; font-style: normal;\">État du compte :</i> ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["account"] ?? null), "owner", []), "html", null, true);
        echo " &nbsp;&nbsp;&nbsp;&nbsp;
            <i style=\"font-weight: bold; font-style: normal;\">Montant disponible :</i> ";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["account"] ?? null), "amount", []), "html", null, true);
        echo " \$ &nbsp;&nbsp;&nbsp;&nbsp;
            <i style=\"font-weight: bold; font-style: normal;\">Dernière opération :</i> ";
        // line 12
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["account"] ?? null), "lastOp", []), "d/m/y"), "html", null, true);
        echo " &nbsp;&nbsp;&nbsp;&nbsp;
            <i style=\"font-weight: bold; font-style: normal;\">Date de création :</i> ";
        // line 13
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["account"] ?? null), "creationDate", []), "d/m/y"), "html", null, true);
        echo "
        </div>
    </div><br><br><br>
    <div class=\"row container-fluid\" style=\"text-align: center\">
        <div class=\"col-md-12\">
            <a style=\"text-decoration: none; color: white;\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("makeChanges", ["id" => $this->getAttribute(($context["account"] ?? null), "id", [])]), "html", null, true);
        echo "\">
                <button class=\"btn btn-danger\">
                    Retour
                </button>
            </a>
        </div>
    </div>
";
    }

    // line 27
    public function block_stylesheets($context, array $blocks = [])
    {
        echo " ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "default/position.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 27,  63 => 18,  55 => 13,  51 => 12,  47 => 11,  43 => 10,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/position.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP2/app/Resources/views/default/position.html.twig");
    }
}
