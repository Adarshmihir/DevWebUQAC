<?php

/* default/createAccount.html.twig */
class __TwigTemplate_6fa792b76eb293dd73062593c72a70863601c6ada9b03ca85263de4d45329774 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/createAccount.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        // line 4
        echo "    <div class=\"container-fluid center-block\" style=\"text-align: center\"><br><br>
        <h1>Créer un compte bancaire</h1>
        ";
        // line 6
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), [0 => "bootstrap_4_layout.html.twig"], true);
        // line 7
        echo "        <div class=\"row\">
            <div class=\"col-md-4\"><br></div>
            <div class=\"col-md-4\">
                ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form');
        echo "
            </div>
        </div>
        <br><br><br><br>
        <div class=\"row\">
            <div class=\"col-md-12\" style=\"text-align: center\">
                <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "\">
                    <button class=\"btn btn-danger\">
                        Revenir à la page d'accueil
                    </button>
                </a>
            </div>
        </div>
    </div>
";
    }

    // line 26
    public function block_stylesheets($context, array $blocks = [])
    {
        echo " ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "default/createAccount.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 26,  52 => 16,  43 => 10,  38 => 7,  36 => 6,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/createAccount.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP2/app/Resources/views/default/createAccount.html.twig");
    }
}
