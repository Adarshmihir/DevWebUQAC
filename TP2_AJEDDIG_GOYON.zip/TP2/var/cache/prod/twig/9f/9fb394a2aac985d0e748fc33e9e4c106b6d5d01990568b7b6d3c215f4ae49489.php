<?php

/* default/remove.html.twig */
class __TwigTemplate_cdefc9a4fff58fc545ad8237cb54956043f5f11fea23b9d43127d8821c45a1bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/remove.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        // line 4
        echo "    <div class=\"container-fluid center-block\" style=\"text-align: center\"><br><br>
        <h1>Retirer de l'argent du compte \"";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["account"] ?? null), "owner", []), "html", null, true);
        echo "\"</h1>
        <div class=\"row\"><br/>
            <div class=\"col-md-5\">
            </div>
            <div class=\"col-md-2\">
                ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form');
        echo "
            </div>
        </div><br><br><br>
        <div class=\"row\" style=\"text-align: center\">
            <div class=\"col-md-12\">
            <a style=\"text-decoration: none; color: white;\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("makeChanges", ["id" => $this->getAttribute(($context["account"] ?? null), "id", [])]), "html", null, true);
        echo "\">
                <button class=\"btn btn-danger\">
                    Retour
                </button>
            </a>
            </div>
        </div>
    </div>
";
    }

    // line 25
    public function block_stylesheets($context, array $blocks = [])
    {
        echo " ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "default/remove.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 25,  51 => 15,  43 => 10,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/remove.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP2/app/Resources/views/default/remove.html.twig");
    }
}
