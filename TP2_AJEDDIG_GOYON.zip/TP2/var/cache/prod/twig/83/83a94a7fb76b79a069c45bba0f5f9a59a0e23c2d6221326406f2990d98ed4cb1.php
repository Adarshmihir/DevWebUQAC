<?php

/* default/makeChanges.html.twig */
class __TwigTemplate_dc214d0f97d4151a0e7a7cc011a85bd3c8d892b6b1a816b6f1f500d4beee0b42 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/makeChanges.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        // line 4
        echo "    <div class=\"container-fluid center-block\" style=\"text-align: center\"><br><br>
        <h1>Faire des opérations sur un compte bancaire</h1><br><br>
        <div class=\"row\">
            <div class=\"col-md-4\">
                <a class=\"btn btn-light btn-outline-dark btn-sm\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("add", ["id" => $this->getAttribute(($context["account"] ?? null), "id", [])]), "html", null, true);
        echo "\">Déposer de l'argent</a>
            </div>
            <div class=\"col-md-4\">
                <a class=\"btn btn-light btn-outline-dark btn-sm\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("remove", ["id" => $this->getAttribute(($context["account"] ?? null), "id", [])]), "html", null, true);
        echo "\">Retirer de l'argent</a>
            </div>
            <div class=\"col-md-4\">
                <a class=\"btn btn-light btn-outline-dark btn-sm\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("position", ["id" => $this->getAttribute(($context["account"] ?? null), "id", [])]), "html", null, true);
        echo "\">Consulter la position d'un compte</a>
            </div>
        </div>
        <br><br><br>
        <div class=\"row center\">
            <div class=\"col-md-3\"></div>
            <div class=\"col-md-6\">
                <i style=\"font-weight: bold; font-style: normal;\">État du compte :</i> ";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["account"] ?? null), "owner", []), "html", null, true);
        echo " &nbsp;&nbsp;&nbsp;&nbsp;
                <i style=\"font-weight: bold; font-style: normal;\">Montant disponible :</i> ";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute(($context["account"] ?? null), "amount", []), "html", null, true);
        echo " \$ &nbsp;&nbsp;&nbsp;&nbsp;
                <i style=\"font-weight: bold; font-style: normal;\">Dernière opération :</i> ";
        // line 23
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["account"] ?? null), "lastOp", []), "d/m/y"), "html", null, true);
        echo "
            </div>
        </div>
        <br><br><br><br>
        <div class=\"row\">
            <div class=\"col-md-12\" style=\"text-align: center\">
                <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "\">
                    <button class=\"btn btn-danger\">
                        Revenir à la page d'accueil
                    </button>
                </a>
            </div>
        </div>

    </div>
";
    }

    // line 40
    public function block_stylesheets($context, array $blocks = [])
    {
        echo " ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "default/makeChanges.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 40,  77 => 29,  68 => 23,  64 => 22,  60 => 21,  50 => 14,  44 => 11,  38 => 8,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "default/makeChanges.html.twig", "/home/faris/eclipse-workspace/DevWebUQAC/TP2/app/Resources/views/default/makeChanges.html.twig");
    }
}
