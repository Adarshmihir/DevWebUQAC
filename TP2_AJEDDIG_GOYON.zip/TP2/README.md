TP2
===

A Symfony project created on February 4, 2019, 10:38 pm.

Si vous reprennez le projet, vous devez avant tout installer composer, et avoir mysql sur votre machine.

Une fois installer, lancer la commande ``composer install`` et suivez les instructions.
Si tout se passe bien, il vous suffit alors de lancer la commande ``php bin/console server:start`` pour lancer l'application (généralement sur localhost:8000, mais le lien vous sera donné dans le terminal.)
